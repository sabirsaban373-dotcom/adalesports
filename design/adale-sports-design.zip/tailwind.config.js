/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                'adale-dark': '#0a0e17',
                'adale-card': '#111625',
                'adale-accent': '#ff2e5c', // Red/Pink from design
                'adale-cyan': '#00ffc8',   // Cyan/Teal
                'adale-purple': '#8e44ad', // Purple hint
                'lakers-gold': '#fdb927',
                'lakers-purple': '#552583',
                'celtics-green': '#007a33',
            },
            fontFamily: {
                sans: ['"Work Sans"', 'sans-serif'],
                display: ['"Space Grotesk"', 'sans-serif'], // Assuming a more display-like font for headers if needed
            }
        },
    },
    plugins: [],
}
